public class Snakegame {
public static void main(String args[]){
     new gameFrame();
}
}
